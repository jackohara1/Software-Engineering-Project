﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hardware_Syst
{
    class DBConnect
    {
        public const string oradb = "Data Source = oracle/orcl; User Id = t00195057; Password = bqfvw4im;";
    }
}
