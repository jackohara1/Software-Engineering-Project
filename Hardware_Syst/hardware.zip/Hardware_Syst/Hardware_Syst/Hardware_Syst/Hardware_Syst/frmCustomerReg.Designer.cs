﻿namespace Hardware_Syst
{
    partial class frmCustomerReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegisterCustomer = new System.Windows.Forms.Button();
            this.txtAddLn1 = new System.Windows.Forms.TextBox();
            this.lblAddLn1 = new System.Windows.Forms.Label();
            this.lblCustomerSurname = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCustomerSurname = new System.Windows.Forms.TextBox();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.txtAddLn2 = new System.Windows.Forms.TextBox();
            this.lblAddLn2 = new System.Windows.Forms.Label();
            this.txtAddLn3 = new System.Windows.Forms.TextBox();
            this.lblAddLn3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.backToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRegisterCustomer
            // 
            this.btnRegisterCustomer.Location = new System.Drawing.Point(289, 302);
            this.btnRegisterCustomer.Name = "btnRegisterCustomer";
            this.btnRegisterCustomer.Size = new System.Drawing.Size(123, 23);
            this.btnRegisterCustomer.TabIndex = 23;
            this.btnRegisterCustomer.Text = "Register Customer";
            this.btnRegisterCustomer.UseVisualStyleBackColor = true;
            this.btnRegisterCustomer.Click += new System.EventHandler(this.btnRegisterCustomer_Click);
            // 
            // txtAddLn1
            // 
            this.txtAddLn1.Location = new System.Drawing.Point(127, 201);
            this.txtAddLn1.Name = "txtAddLn1";
            this.txtAddLn1.Size = new System.Drawing.Size(100, 20);
            this.txtAddLn1.TabIndex = 22;
            // 
            // lblAddLn1
            // 
            this.lblAddLn1.AutoSize = true;
            this.lblAddLn1.Location = new System.Drawing.Point(22, 204);
            this.lblAddLn1.Name = "lblAddLn1";
            this.lblAddLn1.Size = new System.Drawing.Size(77, 13);
            this.lblAddLn1.TabIndex = 21;
            this.lblAddLn1.Text = "Address Line 1";
            // 
            // lblCustomerSurname
            // 
            this.lblCustomerSurname.AutoSize = true;
            this.lblCustomerSurname.Location = new System.Drawing.Point(22, 156);
            this.lblCustomerSurname.Name = "lblCustomerSurname";
            this.lblCustomerSurname.Size = new System.Drawing.Size(96, 13);
            this.lblCustomerSurname.TabIndex = 19;
            this.lblCustomerSurname.Text = "Customer Surname";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(22, 108);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(101, 13);
            this.lblCustomerName.TabIndex = 18;
            this.lblCustomerName.Text = "Customer Forename";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(22, 80);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 17;
            this.lblCustomerID.Text = "Customer_ID";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(127, 105);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerName.TabIndex = 15;
            // 
            // txtCustomerSurname
            // 
            this.txtCustomerSurname.Location = new System.Drawing.Point(127, 153);
            this.txtCustomerSurname.Name = "txtCustomerSurname";
            this.txtCustomerSurname.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerSurname.TabIndex = 14;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtCustomerID.Location = new System.Drawing.Point(127, 77);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(50, 20);
            this.txtCustomerID.TabIndex = 13;
            this.txtCustomerID.Text = "001";
            // 
            // txtAddLn2
            // 
            this.txtAddLn2.Location = new System.Drawing.Point(127, 227);
            this.txtAddLn2.Name = "txtAddLn2";
            this.txtAddLn2.Size = new System.Drawing.Size(100, 20);
            this.txtAddLn2.TabIndex = 25;
            // 
            // lblAddLn2
            // 
            this.lblAddLn2.AutoSize = true;
            this.lblAddLn2.Location = new System.Drawing.Point(22, 230);
            this.lblAddLn2.Name = "lblAddLn2";
            this.lblAddLn2.Size = new System.Drawing.Size(77, 13);
            this.lblAddLn2.TabIndex = 24;
            this.lblAddLn2.Text = "Address Line 2";
            // 
            // txtAddLn3
            // 
            this.txtAddLn3.Location = new System.Drawing.Point(127, 253);
            this.txtAddLn3.Name = "txtAddLn3";
            this.txtAddLn3.Size = new System.Drawing.Size(100, 20);
            this.txtAddLn3.TabIndex = 27;
            // 
            // lblAddLn3
            // 
            this.lblAddLn3.AutoSize = true;
            this.lblAddLn3.Location = new System.Drawing.Point(22, 256);
            this.lblAddLn3.Name = "lblAddLn3";
            this.lblAddLn3.Size = new System.Drawing.Size(77, 13);
            this.lblAddLn3.TabIndex = 26;
            this.lblAddLn3.Text = "Address Line 3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(423, 24);
            this.menuStrip1.TabIndex = 28;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // backToolStripMenuItem
            // 
            this.backToolStripMenuItem.Name = "backToolStripMenuItem";
            this.backToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.backToolStripMenuItem.Text = "Back";
            this.backToolStripMenuItem.Click += new System.EventHandler(this.backToolStripMenuItem_Click);
            // 
            // frmCustomerReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 344);
            this.Controls.Add(this.txtAddLn3);
            this.Controls.Add(this.lblAddLn3);
            this.Controls.Add(this.txtAddLn2);
            this.Controls.Add(this.lblAddLn2);
            this.Controls.Add(this.btnRegisterCustomer);
            this.Controls.Add(this.txtAddLn1);
            this.Controls.Add(this.lblAddLn1);
            this.Controls.Add(this.lblCustomerSurname);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.txtCustomerSurname);
            this.Controls.Add(this.txtCustomerID);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmCustomerReg";
            this.Text = "Register_Customer";
            this.Load += new System.EventHandler(this.frmCustomerReg_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRegisterCustomer;
        private System.Windows.Forms.TextBox txtAddLn1;
        private System.Windows.Forms.Label lblAddLn1;
        private System.Windows.Forms.Label lblCustomerSurname;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtCustomerSurname;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.TextBox txtAddLn2;
        private System.Windows.Forms.Label lblAddLn2;
        private System.Windows.Forms.TextBox txtAddLn3;
        private System.Windows.Forms.Label lblAddLn3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem backToolStripMenuItem;
    }
}